export default class Message {
    static info = (msg) => {}
    static warn = (msg) => {}
    static success = (msg) => {}
    static error = (msg) => {}
}