
import utilities from './utilities'; 

// ==============================|| MENU ITEMS ||============================== //

const menuItems = {
    items: [utilities]
};

export default menuItems;
