import { Box, Stack, Typography, Avatar } from '@mui/material';
import AlignVerticalBottomIcon from '@mui/icons-material/AlignVerticalBottom';
import { useState, useEffect } from 'react';
import classes from './HospitalDetail.scss'
import cookie from 'js-cookie'
 
const HospitalSetAddPage = ({hoscode}) => { 
    
    return <Box className={classes.HospitalSetAddPage}>
        
    </Box>
}
export default HospitalSetAddPage