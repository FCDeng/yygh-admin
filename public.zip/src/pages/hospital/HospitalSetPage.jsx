import { Box, Stack, Typography, Avatar } from '@mui/material';
import AlignVerticalBottomIcon from '@mui/icons-material/AlignVerticalBottom';
import { useState, useEffect } from 'react';
import classes from './index.scss'
import cookie from 'js-cookie'
 
const HospitalSetPage = ({hoscode}) => { 
    
    return <Box className={classes.HospitalSetPage}>
        
    </Box>
}
export default HospitalSetPage